<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\URL;

class AttachmentResource extends JsonResource
{
    public function toArray(Request $request)
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'original_name' => $this->original_name,
            'file_type' => $this->mime_type,
            'file_size_kb' => round($this->file_size / 1024, 2),

            'view_url' => URL::temporarySignedRoute(
                'attachments.view',
                now()->addMinutes(60),
                ['id' => $this->id]
            ),

            'uploaded_by' => new UserResource($this->uploader),
            'uploaded_at' => $this->created_at,
        ];
    }
}
