<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->full_name,
            'national_id' => $this->national_id,
            'email' => $this->email,
            'citizen_details' => new CitizenResource($this->whenLoaded('citizen')),
            'roles' => $this->getRoleNames(),
        ];
    }
}
